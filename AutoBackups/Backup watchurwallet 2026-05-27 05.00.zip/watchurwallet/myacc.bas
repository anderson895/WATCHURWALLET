﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim sql As SQL
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.

	Private EditText1 As EditText
	Private ListView1 As ListView
	Private txtfname As EditText
	Private txtlname As EditText
	Private txtusername As EditText
	Private txtemail As EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	'Do not forget to load the layout file created with the visual designer. For example:
	Activity.LoadLayout("laymyacc")
	sql = Main.sql
	
	LoadAccountInfo
End Sub

Sub Activity_Resume
	
End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Sub LoadAccountInfo
	Dim c As Cursor
	c = sql.ExecQuery2("SELECT fname, lname FROM tblusers WHERE username=?", Array As String(Main.usernamee))
	If c.RowCount > 0 Then
		c.Position = 0
		txtfname.Text = c.GetString2(0)
		txtlname.Text = c.GetString2(1)
	End If
	c.Close
End Sub


Private Sub btneditflname_Click
	
End Sub

Private Sub btnlogout_Click
	
End Sub