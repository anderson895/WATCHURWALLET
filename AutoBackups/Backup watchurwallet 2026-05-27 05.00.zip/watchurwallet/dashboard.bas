﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False 	
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.

End Sub
Sub Globals
	Private btnLogout As Button
	Private lbluserbudget As Label
	Private btnaccount As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("dashboardlayout")
	lbluserbudget.Text = Main.usernamee & " Budget"
End Sub

Private Sub btnLogout_Click
	StartActivity(Main)
	Activity.Finish
End Sub

Private Sub btnaccount_Click
	StartActivity(account)
End Sub