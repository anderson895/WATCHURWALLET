﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim sql As SQL
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private pnlmenu As Panel
	Private Button1 As Button
	Private lblfullname As Label
	Private lblemail As Label
	Private lblusername As Label
	Private btneditexpenses As Button
	Private ListView1 As ListView
	Private EditText1 As EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	sql = Main.sql
	
	Activity.LoadLayout("layaccount")
	pnlmenu.LoadLayout("laymenu")
	pnlmenu.Visible = False
	lblfullname.Text = Main.fname & " " & Main.lname
	lblusername.Text = Main.usernamee
	lblemail.Text = Main.email
End Sub

Sub Activity_Resume
	LoadHistory 
End Sub

Private Sub btnmenu_Click
	pnlmenu.Visible = True
End Sub

Private Sub labelhome_Click
	pnlmenu.Visible = False
	StartActivity(home)
	Activity.Finish
End Sub

Private Sub labelexpenses_Click
	pnlmenu.Visible = False
	StartActivity(expenses)
	Activity.Finish
End Sub

Private Sub labelgoal_Click
	pnlmenu.Visible = False
	StartActivity(goal)
	Activity.Finish
End Sub

Private Sub labelaccount_Click
	pnlmenu.Visible = False
End Sub

Private Sub btneditexpenses_Click
	StartActivity(editexpenses)
End Sub

Private Sub btneditgoals_Click
	StartActivity(editgoals)
End Sub

Private Sub btnsetallowance_Click
	Dim allowanceAmount As Double = EditText1.Text
	Dim date As String = DateTime.Date(DateTime.Now)
	
	sql.ExecNonQuery2("INSERT INTO tblallowance (amount, date) VALUES (?, ?)", Array As Object(allowanceAmount, date))
	sql.ExecNonQuery2("INSERT INTO tbltransac (type, amount, date) VALUES (?, ?, ?)", Array As Object("Allowance", allowanceAmount, date))
	
	LoadHistory
	ToastMessageShow("Allowance Set: " & allowanceAmount, False)
	EditText1.Text = ""
End Sub

Sub LoadHistory
	Dim c1 As Cursor
	c1 = sql.ExecQuery("SELECT type, amount, date FROM tbltransac ORDER BY transac_id DESC")
	ListView1.Clear
	For i = 0 To c1.RowCount - 1
		c1.Position = i
		ListView1.AddSingleLine(c1.GetString2(0) & ": ₱" & NumberFormat(c1.GetDouble2(1),1,2) & " on " & c1.GetString2(2))
	Next
	c1.Close
End Sub