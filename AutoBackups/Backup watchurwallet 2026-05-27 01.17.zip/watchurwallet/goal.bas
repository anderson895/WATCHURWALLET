﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	Dim sql As SQL
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private pnlmenu As Panel
	Private Button1 As Button
	Private txtaddedgoal1 As EditText
	Private txtgoalcategory1 As EditText
	Private ProgressBar1 As ProgressBar
	Private btnaddgoal As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	sql = Main.sql
	Activity.LoadLayout("laygoal")
	pnlmenu.LoadLayout("laymenu")
	pnlmenu.Visible = False
End Sub

Sub Activity_Resume
	LoadGoals 
End Sub

Private Sub btnmenu_Click
	pnlmenu.Visible = True
End Sub

Private Sub labelhome_Click
	pnlmenu.Visible = False
	StartActivity(home)
	Activity.Finish
End Sub

Private Sub labelexpenses_Click
	pnlmenu.Visible = False
	StartActivity(expenses)
	Activity.Finish
End Sub

Private Sub labelgoal_Click
	pnlmenu.Visible = False
End Sub

Private Sub labelaccount_Click
	pnlmenu.Visible = False
	StartActivity(account)
	Activity.Finish
End Sub


Private Sub btnaddgoal_Click
	Dim category As String = txtgoalcategory1.Text
	Dim maxAmt As Double
	Dim currentAmt As Double

	' Convert safely from string to double
	If IsNumber(txtaddedgoal1.Text) Then
		maxAmt = txtaddedgoal1.Text
	Else
		Msgbox("Target amount must be a number","")
		Return
	End If

	If IsNumber(txtaddedgoal1.Text) Then
		currentAmt = txtaddedgoal1.Text
	Else
		currentAmt = 0   ' default kung walang laman
	End If

	If category = "" Or maxAmt <= 0 Then
		Msgbox("Please enter a valid category and target amount","")
		Return
	End If

	sql.ExecNonQuery2("INSERT INTO tblgoal (category, min_amount, max_amount, current_amount) VALUES (?, ?, ?, ?)", _
        Array As Object(category, 0, maxAmt, currentAmt))

	ToastMessageShow("Goal Added: " & category & " - ₱" & currentAmt & "/" & maxAmt, False)
	LoadGoals

	txtgoalcategory1.Text = ""
	txtaddedgoal1.Text = ""
	txtaddedgoal1.Text = ""
End Sub

Sub LoadGoals
	Dim c As Cursor
	c = sql.ExecQuery("SELECT category, current_amount, max_amount FROM tblgoal")
	If c.RowCount > 0 Then
		c.Position = 0
		txtgoalcategory1.Text = c.GetString2(0)
		txtaddedgoal1.Text = c.GetDouble2(1)
		txtaddedgoal1.Text = c.GetDouble2(2)

		If c.GetDouble2(2) > 0 Then
			ProgressBar1.Progress = (c.GetDouble2(1) / c.GetDouble2(2)) * 100
		Else
			ProgressBar1.Progress = 0
		End If
	End If
	c.Close
End Sub