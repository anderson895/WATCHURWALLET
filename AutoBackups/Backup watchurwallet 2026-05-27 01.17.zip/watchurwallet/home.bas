﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	Public ExpenseList As List
	Public CategoryList As List
	Dim sql As SQL
End Sub

Sub Globals
	Private pnlmenu As Panel
	Private btnmenu As Button
	Private txtstudentsname As EditText
	Private txtallowance As EditText
	Private txtdate As EditText
	Private txtspent As EditText
	Private txtbalance As EditText
	Private txtamountexpenses As EditText
	Private spinnercategory As Spinner
	Private btnacceptexpenses As Button
	Private txtamountgoal As EditText
	Private btnacceptgoal As Button
	Private txtgoal As EditText
	
	Dim TotalSpent As Double = 0
	Dim Balance As Double = 0
	Dim Allowance As Double = 0

	Dim GoalAmount As Double = 0
	Dim GoalName As String
End Sub

Sub Activity_Create(FirstTime As Boolean)
	sql = Main.sql
	Activity.LoadLayout("layhome")
	pnlmenu.LoadLayout("laymenu")
	pnlmenu.Visible = False
	
	If ExpenseList.IsInitialized = False Then
		ExpenseList.Initialize
	End If

	If CategoryList.IsInitialized = False Then
		CategoryList.Initialize
	End If

	spinnercategory.Add("Foods & Groceries")
	spinnercategory.Add("Transpo")
	spinnercategory.Add("Rent")
	spinnercategory.Add("School Supplies")
	spinnercategory.Add("School Projects")

	DateTime.DateFormat = "MMMM dd, yyyy"
	txtdate.Text = DateTime.Date(DateTime.Now)

	txtspent.Text = "0.00"
	txtbalance.Text = "0.00"

	txtspent.Enabled = False
	txtbalance.Enabled = False
	txtdate.Enabled = False
	
	txtallowance.Background = Null
	txtamountexpenses.Background = Null
	txtgoal.Background = Null
	txtamountgoal.Background = Null
	
	ShowAllowance
End Sub

Sub Activity_Resume
	ShowAllowance
End Sub

Private Sub btnmenu_Click
	pnlmenu.Visible = True
End Sub

Private Sub labelhome_Click
	pnlmenu.Visible = False
End Sub

Private Sub labelexpenses_Click
	pnlmenu.Visible = False
	StartActivity(expenses)
	Activity.Finish
End Sub

Private Sub labelgoal_Click
	pnlmenu.Visible = False
	StartActivity(goal)
	Activity.Finish
End Sub

Private Sub labelaccount_Click
	pnlmenu.Visible = False
	StartActivity(account)
	Activity.Finish
End Sub

Private Sub btnacceptexpenses_Click

	If txtamountexpenses.Text = "" Then
		ToastMessageShow("Please enter expense amount.", False)
		Return
	End If

	If IsNumber(txtamountexpenses.Text) = False Then
		ToastMessageShow("Numbers only.", False)
		Return
	End If

	Dim Expense As Double
	Expense = txtamountexpenses.Text

	If Expense > Balance Then
		ToastMessageShow("Not enough balance.", False)
		Return
	End If

	TotalSpent = TotalSpent + Expense

	txtspent.Text = NumberFormat(TotalSpent,1,2)

	Balance = Allowance - TotalSpent

	txtbalance.Text = NumberFormat(Balance,1,2)

	Dim Category As String
	Category = spinnercategory.SelectedItem

	ExpenseList.Add(Expense)
	CategoryList.Add(Category)

	ToastMessageShow("Expense added to " & Category, False)

	txtamountexpenses.Text = ""

	ShowAllowance
End Sub

Private Sub btnacceptgoal_Click
	If txtgoal.Text = "" Or txtamountgoal.Text = "" Then
		ToastMessageShow("Complete goal information.", False)
		Return
	End If

	If IsNumber(txtamountgoal.Text) = False Then
		ToastMessageShow("Numbers only.", False)
		Return
	End If

	GoalName = txtgoal.Text
	GoalAmount = txtamountgoal.Text
	
	sql.ExecNonQuery2("INSERT INTO tblgoal (category, goal_amount, current_amount) VALUES (?, ?, ?)", Array As Object(GoalName, GoalAmount))
	ToastMessageShow("Added ₱" & GoalAmount & " to " & GoalName, False)

	txtgoal.Text = ""
	txtamountgoal.Text = ""
End Sub

Private Sub txtallowance_TextChanged (Old As String, New As String)
	If New = "" Then
		txtbalance.Text = "0.00"
		Return
	End If

	If IsNumber(New) Then
		Allowance = New
		Balance = Allowance - TotalSpent
		txtbalance.Text = NumberFormat(Balance,1,2)
	End If
End Sub

Sub ShowAllowance
Dim c As Cursor
c = sql.ExecQuery("SELECT SUM(amount) FROM tblallowance")
If c.RowCount > 0 Then
	c.Position = 0
	Allowance = c.GetDouble2(0)
Else
	Allowance = 0
End If
c.Close

Balance = Allowance - TotalSpent

txtallowance.Text = NumberFormat(Allowance,1,2)
txtspent.Text = NumberFormat(TotalSpent,1,2)
txtbalance.Text = NumberFormat(Balance,1,2)
End Sub