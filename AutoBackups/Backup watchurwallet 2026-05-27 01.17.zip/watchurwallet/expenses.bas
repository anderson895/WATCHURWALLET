﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals

End Sub

Sub Globals
	Private pnlmenu As Panel
	Private btnmenu As Button

	Private txttotweekexp As EditText
	Private listexpenses As ListView

	Private txtsplitbill As EditText
	Private spinnergroup As Spinner
	Private btnevensplit As Button
	Private listsplit As ListView
	Private txtsplitwith As EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("layexpenses")

	pnlmenu.LoadLayout("laymenu")
	pnlmenu.Visible = False

	txttotweekexp.Enabled = False

	LoadExpenses
	LoadSpinnerCategories
	
	txtsplitbill.Background = Null
	txtsplitwith.Background = Null

End Sub

Sub LoadExpenses
	Dim Total As Double = 0

	listexpenses.Clear
	If home.ExpenseList.IsInitialized = False Or home.ExpenseList.Size = 0 Then
		ToastMessageShow("No expenses yet", False)
		txttotweekexp.Text = "₱0.00"
		Return
	End If

	For i = 0 To home.ExpenseList.Size - 1

		Dim Expense As Double = home.ExpenseList.Get(i)
		Dim Category As String = home.CategoryList.Get(i)

		Total = Total + Expense

		listexpenses.AddSingleLine( _
        Category & " - ₱" & NumberFormat(Expense,1,2))

	Next

	txttotweekexp.Text = "₱" & NumberFormat(Total,1,2)
End Sub

Sub LoadSpinnerCategories
	spinnergroup.Clear

	spinnergroup.Add("Foods & Groceries")
	spinnergroup.Add("Transpo")
	spinnergroup.Add("Rent")
	spinnergroup.Add("School Supplies")
	spinnergroup.Add("School Projects")
End Sub

Private Sub btnmenu_Click
	pnlmenu.Visible = True
End Sub

Private Sub labelhome_Click
	pnlmenu.Visible = False
	StartActivity(home)
	Activity.Finish
End Sub

Private Sub labelexpenses_Click
	pnlmenu.Visible = False
End Sub

Private Sub labelgoal_Click
	pnlmenu.Visible = False
	StartActivity(goal)
	Activity.Finish
End Sub

Private Sub labelaccount_Click
	pnlmenu.Visible = False
	StartActivity(account)
	Activity.Finish
End Sub

Private Sub btnevensplit_Click
	If txtsplitbill.Text = "" Or txtsplitwith.Text = "" Then
		ToastMessageShow("Complete split information.", False)
		Return
	End If

	If IsNumber(txtsplitbill.Text) = False Then
		ToastMessageShow("Bill must be number.", False)
		Return
	End If

	If IsNumber(txtsplitwith.Text) = False Then
		ToastMessageShow("Persons must be number.", False)
		Return
	End If

	Dim TotalBill As Double
	Dim Persons As Int
	Dim Share As Double
	Dim Category As String

	TotalBill = txtsplitbill.Text
	Persons = txtsplitwith.Text

	If Persons <= 0 Then
		ToastMessageShow("Persons must be greater than 0.", False)
		Return
	End If

	Share = TotalBill / Persons

	Category = spinnergroup.SelectedItem

	listsplit.AddSingleLine( _
    Category & " - " & _
    Persons & " Person - ₱" & _
    NumberFormat(TotalBill,1,2) & _
    " - ₱" & NumberFormat(Share,1,2) & " each")

	ToastMessageShow("Bill successfully split.", False)

	txtsplitbill.Text = ""
	txtsplitwith.Text = ""
End Sub