﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	'These global variables will be declared once when the application starts.
	'These variables can be accessed from all modules.
	
End Sub

Sub Globals
	'These global variables will be redeclared each time the activity is created.
	'These variables can only be accessed from this module.
	Private pnlmenu As Panel
	Private Button1 As Button
	Private lblfullname As Label
	Private lblemail As Label
	Private lblusername As Label
	Private btneditexpenses As Button
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("layaccount")
	pnlmenu.LoadLayout("laymenu")
	pnlmenu.Visible = False
	lblfullname.Text = Main.fname & " " & Main.lname
	lblusername.Text = Main.usernamee
	lblemail.Text = Main.email
End Sub

Private Sub btnmenu_Click
	pnlmenu.Visible = True
End Sub

Private Sub labelhome_Click
	pnlmenu.Visible = False
	StartActivity(home)
	Activity.Finish
End Sub

Private Sub labelexpenses_Click
	pnlmenu.Visible = False
	StartActivity(expenses)
	Activity.Finish
End Sub

Private Sub labelgoal_Click
	pnlmenu.Visible = False
	StartActivity(goal)
	Activity.Finish
End Sub

Private Sub labelaccount_Click
	pnlmenu.Visible = False
End Sub

Private Sub btneditexpenses_Click
	StartActivity(editexpenses)
End Sub

Private Sub btneditgoals_Click
	StartActivity(editgoals)
End Sub