﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region

Sub Process_Globals
	Dim sql As SQL
	Dim rs As ResultSet
End Sub

Sub Globals
	Private B4XTable1 As B4XTable
	Private btnDelete As Button
	Private btnUpdate As Button
	Dim inpdlg As InputDialog
End Sub

Sub Activity_Create(FirstTime As Boolean)
	If FirstTime Then
		sql.Initialize(File.DirInternal, "saddbb.db", False)
	End If
    
	Activity.LoadLayout("AdminPanelLayout")
    
	B4XTable1.AddColumn("Username", B4XTable1.COLUMN_TYPE_TEXT)
	B4XTable1.AddColumn("Password", B4XTable1.COLUMN_TYPE_TEXT)
	B4XTable1.AddColumn("Role", B4XTable1.COLUMN_TYPE_TEXT)
    
	ShowUsers
End Sub

Sub Activity_Resume
	ShowUsers
End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub

Sub ShowUsers
	Dim data As List
	data.Initialize
    
	rs = sql.ExecQuery("SELECT * FROM tblusers")
    
	Do While rs.NextRow
		Dim row(3) As Object
		row(0) = rs.GetString("username")
		row(1) = rs.GetString("password")
		row(2) = rs.GetString("role")
		data.Add(row)
	Loop
    
	rs.Close
	B4XTable1.SetData(data)
End Sub


Private Sub btnDelete_Click
    
	Dim uname As String
	inpdlg.Input = ""
    
	Dim res As Int = inpdlg.Show("Enter username to delete", "Delete User", "OK", "Cancel", "", Null)
	uname = inpdlg.Input
    
	If res = DialogResponse.POSITIVE Then
        
		Dim c As Cursor
		c = sql.ExecQuery2("SELECT * FROM tblusers WHERE username = ?", Array As String(uname))
        
		If c.RowCount > 0 Then
            
			Dim confirm As Int
			confirm = Msgbox2("Delete this user?", "Confirm", "Yes", "", "No", Null)
            
			If confirm = DialogResponse.POSITIVE Then
				sql.ExecNonQuery2("DELETE FROM tblusers WHERE username = ?", Array As String(uname))
				ShowUsers
				ToastMessageShow("User Deleted", False)
			End If
            
		Else
			Msgbox("User not found", "")
		End If
        
	End If
End Sub

Private Sub btnUpdate_Click
    
	Dim uname As String
	inpdlg.Input = ""
    
	Dim res As Int = inpdlg.Show("Enter username to update", "Update User", "OK", "Cancel", "", Null)
	uname = inpdlg.Input
    
	If res = DialogResponse.POSITIVE Then
        
		Dim c As Cursor
		c = sql.ExecQuery2("SELECT * FROM tblusers WHERE username = ?", Array As String(uname))
        
		If c.RowCount > 0 Then

			inpdlg.Input = ""
			inpdlg.Show("Enter new password", "Update", "OK", "", "", Null)
			Dim newpass As String = inpdlg.Input
            
			inpdlg.Input = ""
			inpdlg.Show("Enter role (admin/user)", "Update", "OK", "", "", Null)
			Dim newrole As String = inpdlg.Input
            
			sql.ExecNonQuery2("UPDATE tblusers SET password=?, role=? WHERE username=?", Array As Object(newpass, newrole, uname))
            
			ShowUsers
			ToastMessageShow("User Updated", False)
            
		Else
			Msgbox("User not found", "")
		End If
        
	End If
End Sub

Private Sub btnBack_Click
	StartActivity(dashboard)
End Sub