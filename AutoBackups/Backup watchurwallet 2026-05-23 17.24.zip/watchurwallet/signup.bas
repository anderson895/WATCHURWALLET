﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.4
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: False
#End Region
Sub Process_Globals
	Dim sql As SQL
End Sub

Sub Globals
	Private txtUser As EditText
	Private txtPass As EditText
	Private btnCreate As Button
	Private txtemail As EditText
	Private txtfname As EditText
	Private txtlname As EditText
End Sub

Sub Activity_Create(FirstTime As Boolean)
	If FirstTime Then
		sql.Initialize(File.DirInternal, "saddbb.db", False)
	End If
	Activity.LoadLayout("SignupLayout")
End Sub

Sub Activity_Resume
	txtUser.Text = ""
	txtPass.Text = ""
	txtemail.Text = ""
	txtfname.Text = ""
	txtlname.Text = ""
	
	txtUser.RequestFocus
End Sub

Private Sub btnCreate_Click
	If txtUser.Text = "" Or txtPass.Text = "" Or txtfname.Text = "" Or txtlname.Text = "" Or txtemail.Text = "" Then
		Msgbox("All fields must be completed.", "")
		Return
	End If

	
	Dim rs As ResultSet
	rs = sql.ExecQuery2("SELECT * FROM tblusers WHERE username = ?", Array As String(txtUser.Text))

	If rs.NextRow Then
		ToastMessageShow("Username already exists!", False)
		rs.Close
	Else
		rs.Close
		sql.ExecNonQuery2("INSERT INTO tblusers VALUES (?,?,?,?,?,?)", Array As Object(txtUser.Text, txtPass.Text, "User", txtfname.Text, txtlname.Text, txtemail.Text))
		ToastMessageShow("Account Created!", False)
		Activity.Finish
	End If
End Sub

Private Sub btnBack_Click
	StartActivity(Main)
End Sub